VLOGSPARK AI 3.0 — FRONTEND

Files
- index.html: complete responsive Apple-inspired frontend (single-file HTML/CSS/JS)

Backend compatibility
- GET  {BACKEND_BASE_URL}/health
- POST {BACKEND_BASE_URL}/api/generate
- POST JSON fields: title, platform, language, style, duration, audience, details
- Expected response fields used by the UI: hook, script, scenes[] (title, visual, voiceover, on_screen_text), caption, hashtags, thumbnail_idea, editing_notes, video_prompt, platform, language, duration.

Run locally
1. Keep your existing FastAPI backend running.
2. Open index.html in a browser, or serve the folder with a static server.
3. Select the gear/settings icon in the top-right.
4. Enter your backend's public base URL, for example https://your-backend.onrender.com (do not add /api/generate).
5. Save. The top status indicator checks GET /health.
6. Generate a plan. The frontend sends POST /api/generate.

GitHub Pages deployment
1. Back up the existing repository first.
2. Replace the published frontend index.html with this index.html.
3. Commit and push to the branch/folder configured for GitHub Pages.
4. Open the published website and set the deployed FastAPI backend URL in Settings.

Important backend notes
- Keep GEMINI_API_KEY only in the backend hosting provider's environment variables.
- Do not put API keys in this HTML file or in GitHub Pages.
- If the browser reports a CORS error, add the exact GitHub Pages origin to the FastAPI CORS allowlist on the backend.
- The existing endpoint paths are preserved: /health and /api/generate. This frontend does not rename or replace backend routes.
- Voice synthesis, actual video generation, and MP4 rendering are not added by this frontend; it displays the content and planning fields returned by the existing API.
